# UAsset Edit (Android)

Small Android editor for cooked Unreal assets (.uasset + .uexp), built on UAssetAPI (the engine behind UAssetGUI).
Not UAssetGUI itself (that is a Windows WinForms app).

## Build
Use a NEW GitHub repo (keeps it separate from the Repak one). Upload the zip to the repo root, then
Add file -> Create new file -> `.github/workflows/build-uassetedit.yml`, paste in the contents of build-uassetedit.yml.
(Or unzip and upload the contents incl. the hidden .github folder.)
Actions -> Build UAssetEdit APK -> download artifact `uassetedit-apk`.

## Use
1. Install the APK, grant "All files access".
2. Browse /storage/emulated/0/RepakWork (where the Repak app unpacks) and tap a .uasset.
   The matching .uexp must be in the same folder.
3. Pick the engine version in the spinner first. If loading fails, try neighbours (VER_UE4_22 ... VER_UE4_27).
4. Filter the property list, tap a row marked * to edit, then Save. Originals are backed up to RepakWork/_backups.
5. Pack the folder with the Repak app (remove unchanged files first).

## Limits
- Editable: float, double, int, int64, int16, uint32, bool, string. Everything else is shown read-only.
- No .usmap (mappings) support, so unversioned/"zen" assets may not load.
- Adding/removing properties is not supported.
