using System.Globalization;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Provider;
using Android.Text;
using Android.Views;
using Android.Widget;
using UAssetAPI;
using UAssetAPI.ExportTypes;
using UAssetAPI.PropertyTypes.Objects;
using UAssetAPI.PropertyTypes.Structs;
using UAssetAPI.UnrealTypes;
using Environment = Android.OS.Environment;

namespace UAssetEdit;

class Row
{
    public string Base;
    public string Label;
    public string TypeName;
    public bool Editable;
    public PropertyData Prop;
}

[Activity(Label = "UAsset Edit", MainLauncher = true, Theme = "@android:style/Theme.Material.NoActionBar")]
public class MainActivity : Activity
{
    LinearLayout root;
    string curDir;
    string workRoot;
    UAsset asset;
    string assetPath;
    bool dirty;
    readonly List<Row> rows = new();
    List<Row> shown = new();
    string filter = "";
    string[] verNames;
    int verIndex;
    ListView list;
    TextView statusView;

    int Dp(int v) => (int)(v * Resources.DisplayMetrics.Density);

    protected override void OnCreate(Bundle savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        workRoot = System.IO.Path.Combine(Environment.ExternalStorageDirectory.AbsolutePath, "RepakWork");
        Directory.CreateDirectory(workRoot);
        curDir = workRoot;

        verNames = Enum.GetNames(typeof(EngineVersion))
            .Where(n => n.StartsWith("VER_UE4") || n.StartsWith("VER_UE5"))
            .Distinct().ToArray();
        verIndex = Math.Max(0, Array.IndexOf(verNames, "VER_UE4_25"));

        root = new LinearLayout(this) { Orientation = Orientation.Vertical };
        root.SetPadding(Dp(12), Dp(12), Dp(12), Dp(12));
        root.SetFitsSystemWindows(true);
        SetContentView(root);
        ShowBrowse();
    }

    protected override void OnResume()
    {
        base.OnResume();
        if (asset == null) ShowBrowse();
    }

    bool HasAccess() => Build.VERSION.SdkInt < BuildVersionCodes.R || Environment.IsExternalStorageManager;

    TextView Text(string s, float size = 14, bool bold = false)
    {
        var t = new TextView(this) { Text = s, TextSize = size };
        if (bold) t.SetTypeface(null, Android.Graphics.TypefaceStyle.Bold);
        return t;
    }

    Button Btn(string s, Action a)
    {
        var b = new Button(this) { Text = s };
        b.Click += (_, _) => a();
        return b;
    }

    void Alert(string title, string msg)
    {
        if (msg.Length > 1800) msg = msg.Substring(0, 1800);
        new AlertDialog.Builder(this).SetTitle(title).SetMessage(msg).SetPositiveButton("OK", (_, _) => { }).Show();
    }

    // ---------------- browser ----------------
    void ShowBrowse()
    {
        asset = null;
        root.RemoveAllViews();
        root.AddView(Text("UAsset Edit", 22, true));

        if (!HasAccess())
        {
            root.AddView(Text("Needs \"All files access\" to read the RepakWork folder."));
            root.AddView(Btn("Grant access", () =>
            {
                var i = new Intent(Settings.ActionManageAppAllFilesAccessPermission,
                    Android.Net.Uri.Parse("package:" + PackageName));
                StartActivity(i);
            }));
            return;
        }

        root.AddView(Text("Engine version (try a few if loading fails):", 12));
        var spin = new Spinner(this);
        spin.Adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleSpinnerItem, verNames);
        spin.SetSelection(verIndex);
        spin.ItemSelected += (_, e) => verIndex = e.Position;
        root.AddView(spin);

        root.AddView(Text(curDir, 12));
        statusView = Text("", 12);
        root.AddView(statusView);

        var entries = new List<(string label, string path, bool dir)>();
        if (curDir != workRoot)
            entries.Add(("..", System.IO.Path.GetDirectoryName(curDir), true));
        try
        {
            foreach (var d in Directory.GetDirectories(curDir).OrderBy(x => x))
                entries.Add(("[DIR] " + System.IO.Path.GetFileName(d), d, true));
            foreach (var f in Directory.GetFiles(curDir, "*.uasset").OrderBy(x => x))
                entries.Add((System.IO.Path.GetFileName(f), f, false));
        }
        catch (Exception ex) { statusView.Text = ex.Message; }

        var lv = new ListView(this);
        lv.Adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1,
            entries.Select(x => x.label).ToList());
        lv.ItemClick += (_, e) =>
        {
            var en = entries[e.Position];
            if (en.dir) { curDir = en.path; ShowBrowse(); }
            else Open(en.path);
        };
        root.AddView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
    }

    void Open(string path)
    {
        statusView.Text = "Loading " + System.IO.Path.GetFileName(path) + " ...";
        var verName = verNames[verIndex];
        Task.Run(() =>
        {
            try
            {
                var ver = (EngineVersion)Enum.Parse(typeof(EngineVersion), verName);
                var a = new UAsset(path, ver); // also reads the matching .uexp in the same folder
                RunOnUiThread(() =>
                {
                    asset = a; assetPath = path; dirty = false;
                    BuildRows();
                    ShowEdit();
                });
            }
            catch (Exception ex)
            {
                RunOnUiThread(() =>
                {
                    statusView.Text = "";
                    Alert("Load failed (" + verName + ")", ex.GetType().Name + ": " + ex.Message +
                        "\n\nTry a different engine version.");
                });
            }
        });
    }

    // ---------------- property rows ----------------
    static string TypeOf(PropertyData p) => p.GetType().Name.Replace("PropertyData", "");

    static bool IsEditable(PropertyData p) =>
        p is FloatPropertyData || p is DoublePropertyData || p is IntPropertyData || p is Int64PropertyData ||
        p is Int16PropertyData || p is UInt32PropertyData || p is BoolPropertyData || p is StrPropertyData;

    static string Describe(PropertyData p)
    {
        try { return p.RawValue?.ToString() ?? "null"; }
        catch { return "..."; }
    }

    void Walk(PropertyData p, string label)
    {
        switch (p)
        {
            case StructPropertyData s when s.Value != null:
                foreach (var c in s.Value) Walk(c, label + "." + c.Name);
                break;
            case ArrayPropertyData a when a.Value != null:
                for (int k = 0; k < a.Value.Length; k++) Walk(a.Value[k], label + "[" + k + "]");
                break;
            default:
                var r = new Row { Base = label + " (" + TypeOf(p) + ")", TypeName = TypeOf(p), Editable = IsEditable(p), Prop = p };
                r.Label = r.Base + " = " + Describe(p);
                rows.Add(r);
                break;
        }
    }

    void BuildRows()
    {
        rows.Clear();
        for (int i = 0; i < asset.Exports.Count; i++)
        {
            var ex = asset.Exports[i];
            var exName = ex.ObjectName?.ToString() ?? "?";
            if (ex is NormalExport ne && ne.Data != null)
                foreach (var p in ne.Data) Walk(p, "[" + i + "]" + exName + "/" + p.Name);
        }
    }

    // ---------------- editor ----------------
    void ShowEdit()
    {
        root.RemoveAllViews();
        root.AddView(Text(System.IO.Path.GetFileName(assetPath), 16, true));
        statusView = Text(rows.Count + " properties. Tap a row to edit (editable: float, int, bool, string).", 12);
        root.AddView(statusView);

        var search = new EditText(this) { Hint = "Filter (e.g. Speed, Health)" };
        search.TextChanged += (_, e) => { filter = e.Text?.ToString() ?? ""; Refresh(); };
        search.Text = filter;
        root.AddView(search);

        var bar = new LinearLayout(this) { Orientation = Orientation.Horizontal };
        bar.AddView(Btn("Back", Back));
        bar.AddView(Btn("Save", Save));
        root.AddView(bar);

        list = new ListView(this);
        list.ItemClick += (_, e) => EditRow(shown[e.Position]);
        root.AddView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        Refresh();
    }

    void Refresh()
    {
        shown = rows.Where(r => filter.Length == 0 || r.Label.Contains(filter, StringComparison.OrdinalIgnoreCase))
                    .Take(3000).ToList();
        list.Adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1,
            shown.Select(r => (r.Editable ? "* " : "  ") + r.Label).ToList());
    }

    void Back()
    {
        if (!dirty) { ShowBrowse(); return; }
        new AlertDialog.Builder(this).SetTitle("Unsaved changes").SetMessage("Discard them?")
            .SetPositiveButton("Discard", (_, _) => ShowBrowse())
            .SetNegativeButton("Cancel", (_, _) => { }).Show();
    }

    void EditRow(Row r)
    {
        if (!r.Editable) { Toast.MakeText(this, "Read-only type: " + r.TypeName, ToastLength.Short).Show(); return; }
        var input = new EditText(this) { Text = Describe(r.Prop) };
        new AlertDialog.Builder(this).SetTitle(r.Base).SetView(input)
            .SetPositiveButton("Set", (_, _) =>
            {
                if (TryEdit(r.Prop, input.Text.Trim()))
                {
                    r.Label = r.Base + " = " + Describe(r.Prop);
                    dirty = true;
                    Refresh();
                }
                else Toast.MakeText(this, "Invalid value for " + r.TypeName, ToastLength.Short).Show();
            })
            .SetNegativeButton("Cancel", (_, _) => { }).Show();
    }

    static bool TryEdit(PropertyData p, string t)
    {
        try
        {
            var ci = CultureInfo.InvariantCulture;
            switch (p)
            {
                case FloatPropertyData f: f.Value = float.Parse(t, ci); return true;
                case DoublePropertyData d: d.Value = double.Parse(t, ci); return true;
                case IntPropertyData i: i.Value = int.Parse(t, ci); return true;
                case Int64PropertyData l: l.Value = long.Parse(t, ci); return true;
                case Int16PropertyData s: s.Value = short.Parse(t, ci); return true;
                case UInt32PropertyData u: u.Value = uint.Parse(t, ci); return true;
                case BoolPropertyData b:
                    b.Value = t == "1" || t.Equals("true", StringComparison.OrdinalIgnoreCase); return true;
                case StrPropertyData st: st.Value = new FString(t); return true;
            }
        }
        catch { }
        return false;
    }

    void Save()
    {
        try
        {
            // Backups go outside the unpacked folders so they never get packed into the pak.
            var bdir = System.IO.Path.Combine(workRoot, "_backups");
            Directory.CreateDirectory(bdir);
            var rel = assetPath.Replace(workRoot, "").Trim('/').Replace('/', '_');
            foreach (var ext in new[] { ".uasset", ".uexp" })
            {
                var src = System.IO.Path.ChangeExtension(assetPath, ext);
                var dst = System.IO.Path.Combine(bdir, System.IO.Path.ChangeExtension(rel, ext));
                if (File.Exists(src) && !File.Exists(dst)) File.Copy(src, dst);
            }
            asset.Write(assetPath);
            dirty = false;
            Toast.MakeText(this, "Saved (original backed up in RepakWork/_backups)", ToastLength.Long).Show();
        }
        catch (Exception ex) { Alert("Save failed", ex.GetType().Name + ": " + ex.Message); }
    }
}
